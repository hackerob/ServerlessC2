import boto3
import json
import os

client = boto3.client('dynamodb')

def lambda_handler(event, context):
  HostsDB = os.environ['HostsDatabase']
  contextLoaded = event['requestContext']
  requestTime = "T_" + str(contextLoaded['requestTimeEpoch'])
  #pull variables from API gateway request
  parameters = json.loads(event['body'])

  response = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression="set taskList = list_append(taskList, :task)",
    ExpressionAttributeValues={
        ':task': {"L": [{ "S": str(requestTime) + ":" + str(parameters['task']) }]}
    },
    ReturnValues="UPDATED_NEW"
  )

  response = {
      'statusCode': 200,
      'body': str(requestTime),
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
  }
  
  return response
  