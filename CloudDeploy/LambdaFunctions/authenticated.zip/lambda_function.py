import boto3
import json
from boto3.dynamodb.types import TypeDeserializer
import os

client = boto3.client('dynamodb')

def dynamo_obj_to_python_obj(dynamo_obj: dict) -> dict:
    deserializer = TypeDeserializer()
    return {
        k: deserializer.deserialize(v) 
        for k, v in dynamo_obj.items()
    } 

def lambda_handler(event, context):
  HostsDB = os.environ['HostsDatabase']
  parameters = event['queryStringParameters']
  if str(parameters) == "None":
    query = client.scan(
      TableName= HostsDB
    )
    query_cleaned = ','.join([json.dumps((dynamo_obj_to_python_obj(item))) for item in query['Items']]) 
    full_query = "[" + query_cleaned + "]"
    #dataJSON = json.dump(dynamo_obj_to_python_obj(query['Items']))


    response = {
      'statusCode': 200,
      'body': full_query,
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
    }
    
    return response
  
  else:
    query = client.get_item(
      TableName= HostsDB,
      Key={
          'hostid': {"S": parameters['hostid'] }
      }
    )
    
    dataJSON = dynamo_obj_to_python_obj(query['Item'])
      
    response = {
      'statusCode': 200,
      'body': json.dumps(dataJSON),
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
    }
      
    return response
  