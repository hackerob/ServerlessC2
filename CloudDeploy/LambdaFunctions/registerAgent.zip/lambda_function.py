import boto3
import random
import string
import datetime
import os

client = boto3.client('dynamodb')

def lambda_handler(event, context):
  HostsDB = os.environ['HostsDatabase']
  #pull variables from API gateway request
  random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for i in range(20))
  connect_timestamp = datetime.datetime.now().strftime("%c")
  contextLoaded = event['requestContext']
  requestTime = str(contextLoaded['requestTimeEpoch'])
  public_ip_source = event['requestContext']['identity']['sourceIp']
  user_agent = event['requestContext']['identity']['userAgent']
  #connect_timestamp = event['requestTimeEpoch']

  data = client.put_item(
    TableName= HostsDB,
    Item={
        'hostid': {"S": random_string},
        'public_ip_source': {"S": public_ip_source},
        'user_agent': {"S": user_agent},
        'birthtime': {"S": requestTime},
        'taskList': {"L": []},
        'task': {"M": {}}
    }
  )

  response = {
      'statusCode': 200,
      'body': random_string,
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
  }
  
  return response
  