import boto3
import json
import os
from amsi_rasta_custom import *
from execute_assembly import *

client = boto3.client('dynamodb')

def lambda_handler(event, context):
  HostsDB = os.environ['HostsDatabase']
  contextLoaded = event['requestContext']
  requestTime = "T_" + str(contextLoaded['requestTimeEpoch'])
  #pull variables from API gateway request
  parameters = json.loads(event['body'])
  
  taskid = str(requestTime)
  
  task = str(parameters['task'])
  if task == "amsi-rasta-custom":
    command = get_amsi_rasta_custom()
    command_type = "amsi-rasta-custom"
  elif task == "execute-assembly":
    command = get_execute_assembly
    command_type = "execute-assembly"
  else:
    command = task
    command_type = "basic-command"

  #create 
  createUniqueTask = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression=f"set task.{taskid}=:c",
    ExpressionAttributeValues={
        ':c': {"M": {}}
    },
    ReturnValues="UPDATED_NEW"
  )

  updateTaskAttributes = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression=f"set task.{taskid}.command=:c, task.{taskid}.commandType=:ct",
    ExpressionAttributeValues={
        ':c': {"S": str(command)},
        ':ct': {"S": str(command_type)}
    },
    ReturnValues="UPDATED_NEW"
  )
  
  #add to task list
  response = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression="set taskList = list_append(taskList, :task)",
    ExpressionAttributeValues={
        ':task': {"L": [{ "S": taskid + ":" + str(command) }]}
    },
    ReturnValues="UPDATED_NEW"
  )

  response = {
      'statusCode': 200,
      'body': taskid,
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
  }
  
  return response
  