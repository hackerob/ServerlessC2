import boto3
import json
import os

client = boto3.client('dynamodb')

def lambda_handler(event, context):
  HostsDB = os.environ['HostsDatabase']
  #pull variables from API gateway request
  contextLoaded = event['requestContext']
  requestTime = str(contextLoaded['requestTimeEpoch'])
  parameters = json.loads(event['body'])

  updateTaskAttributes = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression=f"set task.{parameters['taskid']}.commandResponse=:cr, task.{parameters['taskid']}.commandTime=:ct",
    ExpressionAttributeValues={
        ':cr': {"S": parameters['taskResponse']},
        ':ct': {"S": str(requestTime)}
    },
    ReturnValues="UPDATED_NEW"
  )

  
  removeTask = client.update_item(
    TableName= HostsDB,
    Key={
      'hostid': {"S": parameters['hostid']}
    },
    UpdateExpression="REMOVE taskList[0]"
  )

  response = {
      'statusCode': 200,
      'body': "a",
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
  }
  
  return response
  